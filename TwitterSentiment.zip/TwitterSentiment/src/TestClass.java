import java.io.FileWriter;
import java.io.IOException;

import au.com.bytecode.opencsv.CSVWriter;
public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		 String csv = "G:\\data.csv";
	      CSVWriter writer;
		try {
			writer = new CSVWriter(new FileWriter(csv));
			 //Create record
		      String [] record = "4,David,Miller,Australia,30".split(",");
		      //Write the record to file
		      writer.writeNext(record);
		        
		      //close the writer
		      writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	        
	     

	}

}
