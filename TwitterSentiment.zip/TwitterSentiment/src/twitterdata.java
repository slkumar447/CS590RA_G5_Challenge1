


	import java.io.BufferedReader;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;

	import org.json.JSONException;
	import org.json.JSONObject;

	import java.io.File;
	import java.io.FileWriter;
	import java.io.BufferedWriter;
	import java.io.IOException;
import java.io.FileWriter;
import java.io.IOException;

import au.com.bytecode.opencsv.CSVWriter;

	 

	public class twitterdata {

	    public static void main(String[] args) throws FileNotFoundException, JSONException {

	        String jsonData = "";

	        BufferedReader br = null;

	        BufferedWriter bw = null;

	        try {

	            String line;

	            br = new BufferedReader(new FileReader("G:\\tweetdata1.txt"));

	            while ((line = br.readLine()) != null) {

	                jsonData += line + "\n";

	            }

	        } catch (IOException e) {

	            e.printStackTrace();

	        } finally {

	            try {

	                if (br != null)

	                    br.close();

	            } catch (IOException ex) {

	                ex.printStackTrace();

	            }

	        }

	        // System.out.println("File Content: \n" + jsonData);

	      

	        JSONObject obj = new JSONObject(jsonData); 
	        String data=obj.getString("text");
	        String tweet= data+"/0";
			System.out.println("Tweet: " + obj.getString("text"));
			 String csv = "G:\\data.csv";
		      CSVWriter writer;
			try {
				writer = new CSVWriter(new FileWriter(csv));
				 //Create record
				 String [] headerdata="Tweet/Sentiment".split("/");
			      String [] record = tweet.split("/");
			      //Write the record to file
			      writer.writeNext(headerdata);
			     // writer.writeNext("\n");
			      writer.writeNext(record);
			        
			      //close the writer
			      writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	       // System.out.println("twitter: " + obj.getString("twitter"));

	        //System.out.println("social: " + obj.getJSONObject("social"));

	        String temp = obj.getString("text");

	       /*        

	        

	        try

	        {

	            File file = new File("newLineFileWriter.txt");

	            FileWriter fw = new FileWriter(file);

	            bw = new BufferedWriter(fw);

	            bw.write("These text are written in first line.");

	            bw.newLine();

	            bw.write("These text are written in a new line.");

	        }

	         catch (Exception e)

	            {

	                    System.out.println(e);

	            }

	        finally

	         {

	           try

	            {

	             if (bw != null)

	              {

	                bw.flush();

	                bw.close();

	              }

	            }

	          catch (IOException ex)

	            {

	             ex.printStackTrace();

	            }

	        }

	*/      

	       

	    }

	}
